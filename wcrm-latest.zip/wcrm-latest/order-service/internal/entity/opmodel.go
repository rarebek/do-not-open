package entity

type OPModel struct {
	Id string
	OrderId int64
	ProductID int64
}
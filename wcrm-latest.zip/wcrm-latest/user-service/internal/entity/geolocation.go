package entity

type Geolocation struct {
	Id        int64
	Latitude  float32
	Longitude float32
	OwnerId   string
}

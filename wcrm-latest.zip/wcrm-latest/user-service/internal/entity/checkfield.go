package entity

type CheckFieldRequest struct {
	Field string
	Value string
}